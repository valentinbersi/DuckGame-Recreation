Some test data was taken from third party sources:

* ```test.wav``` is (C) CC-by Martin "JaZzy Jun69le" Pesek
  * https://www.freesound.org/people/junggle/sounds/30341/
  * http://profiles.google.com/jun66le

* ```test.ogg``` is (0) CC0 by fins from www.freesound.org
  * http://www.freesound.org/people/fins/sounds/171671/
  * http://www.freesound.org/people/fins/

* ```Vera.ttf``` is (c) 2003 by Bitstream, Inc. All Rights Reserved.
  Bitstream Vera is a trademark of Bitstream, Inc.
  See Bitstream-Vera-COPYRIGHT.TXT for details
